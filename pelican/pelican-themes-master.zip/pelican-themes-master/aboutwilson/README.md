# aboutwilson

A nice theme using the [bootswatch simplex](http://bootswatch.com/simplex/) layout (bootstrap 3 compliant).

![screenshot](screenshot.png)
